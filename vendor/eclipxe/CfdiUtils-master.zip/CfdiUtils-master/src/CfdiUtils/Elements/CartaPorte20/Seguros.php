<?php

namespace CfdiUtils\Elements\CartaPorte20;

use CfdiUtils\Elements\Common\AbstractElement;

class Seguros extends AbstractElement
{
    public function getElementName(): string
    {
        return 'cartaporte20:Seguros';
    }
}
