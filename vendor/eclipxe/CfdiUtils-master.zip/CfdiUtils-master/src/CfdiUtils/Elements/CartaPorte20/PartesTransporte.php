<?php

namespace CfdiUtils\Elements\CartaPorte20;

use CfdiUtils\Elements\Common\AbstractElement;

class PartesTransporte extends AbstractElement
{
    public function getElementName(): string
    {
        return 'cartaporte20:PartesTransporte';
    }
}
