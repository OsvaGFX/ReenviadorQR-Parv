<?php

namespace CfdiUtils\Elements\CartaPorte20;

use CfdiUtils\Elements\Common\AbstractElement;

class DetalleMercancia extends AbstractElement
{
    public function getElementName(): string
    {
        return 'cartaporte20:DetalleMercancia';
    }
}
