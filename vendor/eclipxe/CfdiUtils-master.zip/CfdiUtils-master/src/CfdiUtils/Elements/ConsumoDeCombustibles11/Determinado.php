<?php

namespace CfdiUtils\Elements\ConsumoDeCombustibles11;

use CfdiUtils\Elements\Common\AbstractElement;

class Determinado extends AbstractElement
{
    public function getElementName(): string
    {
        return 'consumodecombustibles11:Determinado';
    }
}
