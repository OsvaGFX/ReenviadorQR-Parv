<?php

namespace CfdiUtils\Elements\ParcialesConstruccion10;

use CfdiUtils\Elements\Common\AbstractElement;

class Inmueble extends AbstractElement
{
    public function getElementName(): string
    {
        return 'servicioparcial:Inmueble';
    }
}
