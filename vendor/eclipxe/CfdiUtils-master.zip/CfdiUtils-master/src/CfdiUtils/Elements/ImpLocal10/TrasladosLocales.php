<?php

namespace CfdiUtils\Elements\ImpLocal10;

use CfdiUtils\Elements\Common\AbstractElement;

class TrasladosLocales extends AbstractElement
{
    public function getElementName(): string
    {
        return 'implocal:TrasladosLocales';
    }
}
