<?php

namespace CfdiUtils\Elements\Nomina12;

use CfdiUtils\Elements\Common\AbstractElement;

class AccionesOTitulos extends AbstractElement
{
    public function getElementName(): string
    {
        return 'nomina12:AccionesOTitulos';
    }
}
