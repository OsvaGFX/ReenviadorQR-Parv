<?php

namespace CfdiUtils\Elements\Nomina12;

use CfdiUtils\Elements\Common\AbstractElement;

class SubContratacion extends AbstractElement
{
    public function getElementName(): string
    {
        return 'nomina12:SubContratacion';
    }
}
