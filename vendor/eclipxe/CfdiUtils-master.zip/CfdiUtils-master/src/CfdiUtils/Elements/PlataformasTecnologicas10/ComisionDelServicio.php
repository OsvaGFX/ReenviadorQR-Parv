<?php

namespace CfdiUtils\Elements\PlataformasTecnologicas10;

use CfdiUtils\Elements\Common\AbstractElement;

class ComisionDelServicio extends AbstractElement
{
    public function getElementName(): string
    {
        return 'plataformasTecnologicas:ComisionDelServicio';
    }
}
