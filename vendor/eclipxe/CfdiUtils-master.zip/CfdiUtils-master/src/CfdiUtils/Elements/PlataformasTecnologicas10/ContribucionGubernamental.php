<?php

namespace CfdiUtils\Elements\PlataformasTecnologicas10;

use CfdiUtils\Elements\Common\AbstractElement;

class ContribucionGubernamental extends AbstractElement
{
    public function getElementName(): string
    {
        return 'plataformasTecnologicas:ContribucionGubernamental';
    }
}
