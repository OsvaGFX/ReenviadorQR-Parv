<?php

namespace CfdiUtils\Elements\PlataformasTecnologicas10;

use CfdiUtils\Elements\Common\AbstractElement;

class ImpuestosTrasladadosdelServicio extends AbstractElement
{
    public function getElementName(): string
    {
        return 'plataformasTecnologicas:ImpuestosTrasladadosdelServicio';
    }
}
