<?php

namespace CfdiUtils\Elements\Cce11;

use CfdiUtils\Elements\Common\AbstractElement;

class DescripcionesEspecificas extends AbstractElement
{
    public function getElementName(): string
    {
        return 'cce11:DescripcionesEspecificas';
    }
}
