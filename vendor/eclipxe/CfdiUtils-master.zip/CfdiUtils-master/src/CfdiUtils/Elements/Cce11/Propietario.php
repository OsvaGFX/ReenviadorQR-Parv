<?php

namespace CfdiUtils\Elements\Cce11;

use CfdiUtils\Elements\Common\AbstractElement;

class Propietario extends AbstractElement
{
    public function getElementName(): string
    {
        return 'cce11:Propietario';
    }
}
