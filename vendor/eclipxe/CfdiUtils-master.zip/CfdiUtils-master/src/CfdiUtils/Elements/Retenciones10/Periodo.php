<?php

namespace CfdiUtils\Elements\Retenciones10;

use CfdiUtils\Elements\Common\AbstractElement;

class Periodo extends AbstractElement
{
    public function getElementName(): string
    {
        return 'retenciones:Periodo';
    }
}
