<?php

namespace CfdiUtils\Elements\Retenciones10;

use CfdiUtils\Elements\Common\AbstractElement;

class Extranjero extends AbstractElement
{
    public function getElementName(): string
    {
        return 'retenciones:Extranjero';
    }
}
