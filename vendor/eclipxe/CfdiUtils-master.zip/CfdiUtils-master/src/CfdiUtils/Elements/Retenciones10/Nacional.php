<?php

namespace CfdiUtils\Elements\Retenciones10;

use CfdiUtils\Elements\Common\AbstractElement;

class Nacional extends AbstractElement
{
    public function getElementName(): string
    {
        return 'retenciones:Nacional';
    }
}
