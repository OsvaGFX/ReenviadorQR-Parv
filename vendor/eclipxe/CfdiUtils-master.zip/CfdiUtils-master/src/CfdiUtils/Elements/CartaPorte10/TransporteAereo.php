<?php

namespace CfdiUtils\Elements\CartaPorte10;

use CfdiUtils\Elements\Common\AbstractElement;

class TransporteAereo extends AbstractElement
{
    public function getElementName(): string
    {
        return 'cartaporte:TransporteAereo';
    }
}
