<?php

namespace CfdiUtils\Elements\CartaPorte10;

use CfdiUtils\Elements\Common\AbstractElement;

class Destino extends AbstractElement
{
    public function getElementName(): string
    {
        return 'cartaporte:Destino';
    }
}
