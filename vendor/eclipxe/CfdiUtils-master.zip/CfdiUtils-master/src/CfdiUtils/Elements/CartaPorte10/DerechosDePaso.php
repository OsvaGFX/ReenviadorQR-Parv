<?php

namespace CfdiUtils\Elements\CartaPorte10;

use CfdiUtils\Elements\Common\AbstractElement;

class DerechosDePaso extends AbstractElement
{
    public function getElementName(): string
    {
        return 'cartaporte:DerechosDePaso';
    }
}
