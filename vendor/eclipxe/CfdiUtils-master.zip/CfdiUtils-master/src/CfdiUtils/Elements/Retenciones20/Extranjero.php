<?php

namespace CfdiUtils\Elements\Retenciones20;

use CfdiUtils\Elements\Common\AbstractElement;

class Extranjero extends AbstractElement
{
    public function getElementName(): string
    {
        return 'retenciones:Extranjero';
    }
}
