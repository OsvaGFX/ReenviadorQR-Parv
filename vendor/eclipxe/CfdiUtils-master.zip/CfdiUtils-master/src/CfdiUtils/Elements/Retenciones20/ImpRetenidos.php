<?php

namespace CfdiUtils\Elements\Retenciones20;

use CfdiUtils\Elements\Common\AbstractElement;

class ImpRetenidos extends AbstractElement
{
    public function getElementName(): string
    {
        return 'retenciones:ImpRetenidos';
    }
}
