<?php

namespace CfdiUtils\Elements\LeyendasFiscales10;

use CfdiUtils\Elements\Common\AbstractElement;

class Leyenda extends AbstractElement
{
    public function getElementName(): string
    {
        return 'leyendasFisc:Leyenda';
    }
}
