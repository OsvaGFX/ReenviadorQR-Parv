<?php

namespace CfdiUtils\Elements\NotariosPublicos10;

use CfdiUtils\Elements\Common\AbstractElement;

class DatosOperacion extends AbstractElement
{
    public function getElementName(): string
    {
        return 'notariospublicos:DatosOperacion';
    }
}
