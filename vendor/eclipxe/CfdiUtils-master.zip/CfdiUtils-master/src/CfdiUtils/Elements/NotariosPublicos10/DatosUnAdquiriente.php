<?php

namespace CfdiUtils\Elements\NotariosPublicos10;

use CfdiUtils\Elements\Common\AbstractElement;

class DatosUnAdquiriente extends AbstractElement
{
    public function getElementName(): string
    {
        return 'notariospublicos:DatosUnAdquiriente';
    }
}
