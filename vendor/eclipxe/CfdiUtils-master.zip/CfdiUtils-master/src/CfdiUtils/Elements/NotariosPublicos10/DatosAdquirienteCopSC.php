<?php

namespace CfdiUtils\Elements\NotariosPublicos10;

use CfdiUtils\Elements\Common\AbstractElement;

class DatosAdquirienteCopSC extends AbstractElement
{
    public function getElementName(): string
    {
        return 'notariospublicos:DatosAdquirienteCopSC';
    }
}
