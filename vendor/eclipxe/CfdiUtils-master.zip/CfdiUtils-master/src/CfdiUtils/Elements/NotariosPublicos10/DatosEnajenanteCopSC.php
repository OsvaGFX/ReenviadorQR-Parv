<?php

namespace CfdiUtils\Elements\NotariosPublicos10;

use CfdiUtils\Elements\Common\AbstractElement;

class DatosEnajenanteCopSC extends AbstractElement
{
    public function getElementName(): string
    {
        return 'notariospublicos:DatosEnajenanteCopSC';
    }
}
