<?php

namespace CfdiUtils\Elements\NotariosPublicos10;

use CfdiUtils\Elements\Common\AbstractElement;

class DescInmueble extends AbstractElement
{
    public function getElementName(): string
    {
        return 'notariospublicos:DescInmueble';
    }
}
