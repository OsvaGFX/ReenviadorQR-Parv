<?php

namespace CfdiUtils\Elements\Pagos20;

use CfdiUtils\Elements\Common\AbstractElement;

class RetencionDR extends AbstractElement
{
    public function getElementName(): string
    {
        return 'pago20:RetencionDR';
    }
}
