<?php

namespace CfdiUtils\Elements\Pagos20;

use CfdiUtils\Elements\Common\AbstractElement;

class TrasladoP extends AbstractElement
{
    public function getElementName(): string
    {
        return 'pago20:TrasladoP';
    }
}
