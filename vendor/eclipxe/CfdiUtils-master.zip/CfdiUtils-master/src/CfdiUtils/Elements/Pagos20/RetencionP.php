<?php

namespace CfdiUtils\Elements\Pagos20;

use CfdiUtils\Elements\Common\AbstractElement;

class RetencionP extends AbstractElement
{
    public function getElementName(): string
    {
        return 'pago20:RetencionP';
    }
}
