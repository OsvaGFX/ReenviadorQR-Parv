<?php

namespace CfdiUtils\Elements\Dividendos10;

use CfdiUtils\Elements\Common\AbstractElement;

class Remanente extends AbstractElement
{
    public function getElementName(): string
    {
        return 'dividendos:Remanente';
    }
}
