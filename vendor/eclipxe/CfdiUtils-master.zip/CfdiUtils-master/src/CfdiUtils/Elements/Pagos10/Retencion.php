<?php

namespace CfdiUtils\Elements\Pagos10;

use CfdiUtils\Elements\Common\AbstractElement;

class Retencion extends AbstractElement
{
    public function getElementName(): string
    {
        return 'pago10:Retencion';
    }
}
