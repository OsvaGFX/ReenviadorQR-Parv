<?php

namespace CfdiUtils\Elements\Pagos10;

use CfdiUtils\Elements\Common\AbstractElement;

class DoctoRelacionado extends AbstractElement
{
    public function getElementName(): string
    {
        return 'pago10:DoctoRelacionado';
    }
}
