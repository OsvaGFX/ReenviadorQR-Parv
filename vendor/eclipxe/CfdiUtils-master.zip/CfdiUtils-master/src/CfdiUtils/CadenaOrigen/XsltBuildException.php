<?php

namespace CfdiUtils\CadenaOrigen;

class XsltBuildException extends \RuntimeException
{
}
