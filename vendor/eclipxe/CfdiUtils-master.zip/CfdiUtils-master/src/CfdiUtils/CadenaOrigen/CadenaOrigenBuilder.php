<?php

namespace CfdiUtils\CadenaOrigen;

/**
 * Use some implementation of XsltBuilderInterface
 * @see DOMBuilder
 * @deprecated :3.0.0 in favor of DOMBuilder
 * @codeCoverageIgnore
 */
class CadenaOrigenBuilder extends DOMBuilder
{
}
