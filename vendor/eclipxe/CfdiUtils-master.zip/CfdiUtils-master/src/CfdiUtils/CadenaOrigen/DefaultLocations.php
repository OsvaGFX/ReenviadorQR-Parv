<?php

namespace CfdiUtils\CadenaOrigen;

/**
 * @see CfdiDefaultLocations
 * @deprecated :3.0.0 in favor of CfdiDefaultLocations
 * @codeCoverageIgnore
 */
class DefaultLocations extends CfdiDefaultLocations
{
}
