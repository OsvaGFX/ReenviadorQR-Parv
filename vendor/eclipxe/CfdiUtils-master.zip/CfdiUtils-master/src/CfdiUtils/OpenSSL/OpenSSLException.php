<?php

namespace CfdiUtils\OpenSSL;

class OpenSSLException extends \RuntimeException
{
}
