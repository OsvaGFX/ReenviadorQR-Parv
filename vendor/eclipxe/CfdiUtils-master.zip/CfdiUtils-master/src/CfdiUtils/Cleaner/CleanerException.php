<?php

namespace CfdiUtils\Cleaner;

class CleanerException extends \RuntimeException
{
}
