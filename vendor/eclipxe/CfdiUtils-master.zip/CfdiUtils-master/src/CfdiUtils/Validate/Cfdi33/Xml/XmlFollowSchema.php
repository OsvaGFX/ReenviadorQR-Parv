<?php

namespace CfdiUtils\Validate\Cfdi33\Xml;

/**
 * XmlFollowSchema valida que el contenido XML sigue los esquemas XSD
 * @deprecated :3.0.0
 */
class XmlFollowSchema extends \CfdiUtils\Validate\Xml\XmlFollowSchema
{
}
