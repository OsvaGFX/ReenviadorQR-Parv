<?php

namespace CfdiUtils\Validate\Contracts;

use CfdiUtils\CadenaOrigen\XsltBuilderPropertyInterface;

interface RequireXsltBuilderInterface extends XsltBuilderPropertyInterface
{
}
