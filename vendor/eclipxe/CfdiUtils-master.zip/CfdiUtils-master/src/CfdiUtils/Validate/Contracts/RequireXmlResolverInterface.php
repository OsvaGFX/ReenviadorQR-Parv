<?php

namespace CfdiUtils\Validate\Contracts;

use CfdiUtils\XmlResolver\XmlResolverPropertyInterface;

interface RequireXmlResolverInterface extends XmlResolverPropertyInterface
{
}
