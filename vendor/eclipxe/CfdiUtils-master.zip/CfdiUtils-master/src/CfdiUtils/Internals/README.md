# CfdiUtils\Internals

Dear user of `CfdiUtils`:

**This namespace is for project internal usage.**
**Do not use any of the elements (classes, traits, etc) stored in this namespaces.**

The elements on this namespace could change and it won't be considered a Breack Compatilibity Change.

The elements on this namespace must never be exposed outside this library (by example, by return).

The elements on this namespace have the `@internal` annotation, if you use an IDE or a code inspector
you will be warned about it.
