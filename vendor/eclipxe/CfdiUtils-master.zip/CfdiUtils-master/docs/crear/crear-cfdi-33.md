# Creación de CFDI 3.3

Por favor, lee la documentación de cómo [crear un CFDI 4.0](crear-cfdi-40.md).
Todas las reglas generales de creación aplican para CFDI 3.3.

Utiliza los elementos de ayuda del espacio de nombres `CfdiUtils\Elements\Cfdi33`
y el objeto de creación `CfdiUtils\CfdiCreator33`.

Dado que el SAT suspendió el uso de la versión 3.3, las clases dedicadas a la creación de
CFDI en estas versiones quedará sin soporte y desaparecerá en la siguiente versión mayor.
